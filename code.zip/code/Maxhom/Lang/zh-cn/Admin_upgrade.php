<?php 
return array(
	'upgrade_error'=>'升级失败!',
	'upgrade_ok'=>'升级成功!',
	'failed'=>'失败',
	'to'=>'到',
	'copy'=>'复制',
	'editfiles'=>'被修改的文件',
	'file_size'=>'文件大小',
	'file_edittime'=>'最后修改日期',
	'lostfile'=>'丢失的文件',
	'unknowfile'=>'未知文件',
	'only_show_php_file'=>'仅显示php文件',
	'tit_msg'=>'注意：升级程序有可能覆盖模版文件，请注意备份！linux服务器需检查文件所有者权限和组权限，确保WEB SERVER用户有文件写入权限',
	'current_version'=>'当前版本:',
	'uptime'=>'更新日期:',
	'upgrade_var_list'=>'可升级版本列表', 
	'latest_version'=>'已经是最新版本了！',
	'cover_html_file'=>'覆盖模版？',
	'start_upgrade'=>'开始升级',
	'view'=>'查看',
	'gourl'=>'访问',
);
?>