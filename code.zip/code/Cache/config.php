<?php
/**
 * 
 * 鏁版嵁搴撻厤缃枃浠�
 *
 * @package      	maxhom
 * @author          www.maxhom.com QQ:1519287158 <1519287158@qq.com>
 * @copyright     	Copyright (c) 2008-2011  (http://www.maxhom.com)
 * @license         http://www.maxhom.com/license.txt
 * @version        	config.php v2.0 2011-03-01 maxhom.cn $
 */
 return array(
	'DB_TYPE'=>'mysql',
	'DB_HOST'=>'localhost',
	//'DB_HOST'=>'new.maxhom.com',
	'DB_NAME'=>'tosee_website',
	'DB_USER'=>'root',
	'DB_PWD'=>'root',
	'DB_PORT'=>'3306',
	'DB_PREFIX'=>'maxhom_',
);
?>