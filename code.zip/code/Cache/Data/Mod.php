<?php
return array ( 'Page' => '1', 'Article' => '2', 'Product' => '3', 'Picture' => '4', 'Download' => '5', 'Feedback' => '6', 'Link' => '7', 'Guestbook' => '8', 'Kefu' => '9', 'Case' => '23', ); ?>