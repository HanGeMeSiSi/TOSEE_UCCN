//手机跳转
function uaredirect(murl){	
	if ((navigator.userAgent.match(/(iPhone|iPod|Android|ios|iPad)/i))) {
		location.replace(murl);
	}
}
